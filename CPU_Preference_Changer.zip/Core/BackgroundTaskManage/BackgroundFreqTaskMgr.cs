﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CPU_Preference_Changer.Core.BackgroundTaskManage {
    class BackgroundTaskMgr {
    }
}
